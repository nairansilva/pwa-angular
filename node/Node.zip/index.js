const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const { salvarSeguro, listarSeguros } = require('./seguro-service.ts');
const webpush = require('web-push');
const { adicionaPushSubscriber } = require('./adiciona-push-subscriber');
const { enviarNotificacao } = require('./enviar-notificacao');

// VAPID keys should only be generated only once.
const vapidKeys = {
    publicKey: 'BMCkvg_QxWOCgS7r4oFyyUVB4oYXx8-522lgkoA2PoKyfc9bckUfq1jldhzTpoGlj81-yoFtfCKyfqayLTNps7A',
    privateKey: 'M7RJCNMBy9EsmtJGQ0DXqbrI-dgKLZG9zkQ6-AF66Dw'
}

webpush.setVapidDetails(
    'mailto:example@yourdomain.org',
    vapidKeys.publicKey,
    vapidKeys.privateKey
);

const app = express();
app.use(bodyParser.json());
app.use(cors({ origin: true, credentials: true }));

app.route('/api/notificacao')
    .post(adicionaPushSubscriber);

app.route('/api/notificacao/enviar')
    .post(enviarNotificacao);

app.route('/api/seguros').post(salvarSeguro);
app.route('/api/seguros').get(listarSeguros);

const HOST = "localhost";
const PORT = "9090";

const httpServer = app.listen(PORT, HOST, () => {
    console.log(`Servidor rodando em http://${HOST}:${PORT}`)
})